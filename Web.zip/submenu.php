<div class="menu mt-1">
    <div class="log-out ">
        <p>Logout</p>
    </div>
    <hr>
    <div class="settings">
        <p>Settings</p>
    </div>
    <hr>
</div>