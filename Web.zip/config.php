<?php 
$dbhost='localhost';
$dbuser_name='root';
$dbname='chatworld';
$pass='';
$conn=mysqli_connect($dbhost,$dbuser_name,$pass,$dbname) or die('connectin error');

?>