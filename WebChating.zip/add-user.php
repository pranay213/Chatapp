<div class="head">
          <div class="col-9">
          <i class="far fa-arrow-alt-circle-left back mt-2 pr-3"></i>
          <p>ChatApp</p>
          </div>
         
          <div class="col-3">

          </div>
         
      </div>
      <div class="body">
          <ul>
              <li>
              <img src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png" alt="">
              <p class="add-n-c">Add New Contact +</p>
              </li>
              
              

          </ul>
        
      </div>