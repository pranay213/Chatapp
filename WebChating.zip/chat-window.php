<div class="head">
          <div class="col-9">
          <i class="far fa-arrow-alt-circle-left back mt-2 pr-3"></i>
          
              
              <img class="mt-2 " style="width:30px; height:30px"src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png" alt="">
              <p class="ml-3 mt-1">User</p>
          
          </div>
         
          <div class="col-3">

          </div>
         
      </div>
      <div class="body">
          
        
      </div>