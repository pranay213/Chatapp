<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/chat.css">
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    <title>Chat</title>
</head>
<body>
  <div class="container-fluid chat-div">
      <div class="head">
          <div class="col-9">
          <p>ChatApp</p>
          </div>
         
          <div class="col-3">
          <i class="fas fa-search"></i>
          <i class="fas fa-ellipsis-v"></i>
          </div>
         
      </div>
      <div class="body">
          <ul>
              <li>
              <img src="https://i.pinimg.com/originals/51/f6/fb/51f6fb256629fc755b8870c801092942.png" alt="">
              <p>User1</p>
              </li>
              <li>
              <img src="https://www.pavilionweb.com/wp-content/uploads/2017/03/man-300x300.png" alt="">
              <p>User2</p>
              </li>
              

          </ul>
        <div class="add-user">
        <i class="fas fa-plus-square"></i>
        </div>
      </div>
  </div>

  <script src="js/fontawesome.js"></script>
  <script src="js/jQuery.js"></script>
  <script src="js/bootstrap.js"></script>
  <script>
     $(document).ready(function()
     {
        $('.add-user').on("click",function()
      {     $.ajax({
          url:"add-user.php",
          type:'post',
          success:function(data)
          {
            $('.chat-div').html(data)
            $('.add-user').css({"display":"none"});
          }
      })

      })
      $(document).on('click','.back',function(){
        $.ajax({
          url:"chat.php",
          type:'post',
          success:function(data)
          {
            $('body').html(data)
            
           
          }
      })
     })
     $(document).on('click',".add-n-c",function()
     {
         $.ajax({
             url:'add-contact.php',
             type:'post',
             success:function(data)
             {
                 $('.body').html(data)
             }
         })
     })
     $('ul li p').on('click',function()
     {
       $.ajax({
         url:"chat-window.php",
         type:'post',
         success:function(data)
         {
           $('.chat-div').html(data);
         }
       })
     })
     })
  </script>
</body>
</html>