<div class="form-group p-3 form-1">
    <input  type="number" class="form-control mt-3 " placeholder="contact number" maxlength='10'>
    <i class="fas fa-arrow-right mt-4 ml-3 "></i>
</div>