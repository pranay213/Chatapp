<?php 
$conn=mysqli_connect('localhost','root','','chatworld') or die('connectin error');

?>